//
//  Habit_Tracker_AppTests.swift
//  Habit Tracker AppTests
//
//  Created by Lohith on 3/28/25.
//

import Testing
@testable import Habit_Tracker_App

struct Habit_Tracker_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
